package com.example.Aula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaApplicationTests {

	@Test
	void contextLoads() {
	}

}
